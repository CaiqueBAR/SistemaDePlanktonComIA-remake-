import torch
import torch.nn as nn
import torchvision.transforms as transforms
import torchvision.models as models
from PIL import Image
import numpy as np
import os
import json

class PlanktonClassifierPyTorch:
    def __init__(self, model_path=None):
        """
        Inicializa o classificador de plâncton usando PyTorch.
        
        Args:
            model_path (str): Caminho para o modelo pré-treinado (opcional)
        """
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = None
        self.class_names = [
            'Copepod',
            'Diatom',
            'Dinoflagellate',
            'Radiolarian',
            'Foraminifera',
            'Cyanobacteria',
            'Other'
        ]
        self.img_size = (224, 224)
        
        # Define as transformações para a imagem
        self.transform = transforms.Compose([
            transforms.Resize(self.img_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ])
        
        if model_path and os.path.exists(model_path):
            self.load_model(model_path)
        else:
            self.create_model()
    
    def create_model(self):
        """
        Cria um modelo CNN para classificação de plâncton usando MobileNetV2 pré-treinado.
        """
        # Carrega o modelo MobileNetV2 pré-treinado
        self.model = models.mobilenet_v2(weights=models.MobileNet_V2_Weights.IMAGENET1K_V1)
        
        # Congela os parâmetros do modelo base
        for param in self.model.parameters():
            param.requires_grad = False
            
        # Substitui a camada classificadora final
        num_ftrs = self.model.classifier[1].in_features
        self.model.classifier[1] = nn.Linear(num_ftrs, len(self.class_names))
        
        self.model = self.model.to(self.device)
        
        print("Modelo PyTorch criado com sucesso!")
        print(f"Classes: {self.class_names}")
    
    def preprocess_image(self, image_path):
        """
        Pré-processa uma imagem para classificação usando as transformações definidas.
        
        Args:
            image_path (str): Caminho para a imagem
            
        Returns:
            torch.Tensor: Imagem pré-processada como tensor PyTorch
        """
        try:
            img = Image.open(image_path).convert("RGB")
            img_tensor = self.transform(img)
            img_tensor = img_tensor.unsqueeze(0)  # Adiciona dimensão do batch
            return img_tensor.to(self.device)
        except Exception as e:
            print(f"Erro no pré-processamento da imagem: {e}")
            return None
    
    def predict(self, image_path):
        """
        Faz a predição para uma imagem de plâncton.
        
        Args:
            image_path (str): Caminho para a imagem
            
        Returns:
            dict: Resultado da predição com classe e confiança
        """
        if self.model is None:
            return {"error": "Modelo não carregado"}
        
        processed_img = self.preprocess_image(image_path)
        if processed_img is None:
            return {"error": "Erro no pré-processamento da imagem"}
        
        self.model.eval()  # Coloca o modelo em modo de avaliação
        with torch.no_grad():
            outputs = self.model(processed_img)
            probabilities = torch.nn.functional.softmax(outputs, dim=1)[0]
            
            # Obtém a classe com maior probabilidade
            confidence, predicted_class_idx = torch.max(probabilities, 0)
            
            predicted_class = self.class_names[predicted_class_idx.item()]
            confidence = confidence.item()
            
            # Cria o resultado detalhado
            result = {
                "predicted_class": predicted_class,
                "confidence": confidence,
                "all_predictions": {}
            }
            
            # Adiciona todas as probabilidades
            for i, class_name in enumerate(self.class_names):
                result["all_predictions"][class_name] = probabilities[i].item()
            
            return result
            
    def save_model(self, save_path):
        """
        Salva o modelo treinado.
        
        Args:
            save_path (str): Caminho para salvar o modelo
        """
        if self.model is None:
            print("Nenhum modelo para salvar")
            return False
        
        try:
            torch.save(self.model.state_dict(), save_path)
            
            # Salva também os nomes das classes
            class_names_path = save_path.replace(".pth", "_classes.json")
            with open(class_names_path, 'w') as f:
                json.dump(self.class_names, f)
            
            print(f"Modelo PyTorch salvo em: {save_path}")
            return True
            
        except Exception as e:
            print(f"Erro ao salvar modelo PyTorch: {e}")
            return False
    
    def load_model(self, model_path):
        """
        Carrega um modelo pré-treinado.
        
        Args:
            model_path (str): Caminho para o modelo
        """
        try:
            self.create_model() # Primeiro cria a arquitetura do modelo
            self.model.load_state_dict(torch.load(model_path, map_location=self.device))
            self.model.eval() # Coloca o modelo em modo de avaliação
            
            # Tenta carregar os nomes das classes
            class_names_path = model_path.replace(".pth", "_classes.json")
            if os.path.exists(class_names_path):
                with open(class_names_path, 'r') as f:
                    self.class_names = json.load(f)
            
            print(f"Modelo PyTorch carregado de: {model_path}")
            print(f"Classes: {self.class_names}")
            return True
            
        except Exception as e:
            print(f"Erro ao carregar modelo PyTorch: {e}")
            return False
    
    def get_model_info(self):
        """
        Retorna informações sobre o modelo.
        
        Returns:
            dict: Informações do modelo
        """
        if self.model is None:
            return {"error": "Modelo não carregado"}
        
        return {
            "classes": self.class_names,
            "num_classes": len(self.class_names),
            "input_shape": self.img_size,
            "model_loaded": True
        }

# Função para criar uma instância do classificador
def create_plankton_classifier():
    """
    Cria e retorna uma instância do classificador de plâncton.
    """
    return PlanktonClassifierPyTorch()

# Teste básico do modelo
if __name__ == "__main__":
    print("Testando o classificador de plâncton com PyTorch...")
    
    # Cria o classificador
    classifier = PlanktonClassifierPyTorch()
    
    # Mostra informações do modelo
    info = classifier.get_model_info()
    print(f"Informações do modelo: {info}")
    
    # Salva o modelo
    classifier.save_model("plankton_model.pth")
    
    print("Teste concluído!")


