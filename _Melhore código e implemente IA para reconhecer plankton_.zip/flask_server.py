from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS
import os
import base64
from werkzeug.utils import secure_filename
from plankton_ai import PlanktonClassifierPyTorch  # Importa a classe PyTorch
import tempfile
import uuid

app = Flask(__name__)
CORS(app)  # Permite requisições de qualquer origem

# Configurações
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp', 'tiff'}
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH

# Cria a pasta de uploads se não existir
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Inicializa o classificador de plâncton (agora PyTorch)
plankton_classifier = PlanktonClassifierPyTorch()

def allowed_file(filename):
    """Verifica se o arquivo tem uma extensão permitida."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    """Página inicial com informações da API."""
    html_template = """
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>API de Reconhecimento de Plâncton</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                background-color: #f5f5f5;
            }
            .container {
                background-color: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            h1 {
                color: #2c3e50;
                text-align: center;
            }
            .endpoint {
                background-color: #ecf0f1;
                padding: 15px;
                margin: 10px 0;
                border-radius: 5px;
                border-left: 4px solid #3498db;
            }
            .method {
                font-weight: bold;
                color: #e74c3c;
            }
            .status {
                background-color: #d5f4e6;
                padding: 10px;
                border-radius: 5px;
                margin: 20px 0;
                text-align: center;
            }
            code {
                background-color: #f8f9fa;
                padding: 2px 5px;
                border-radius: 3px;
                font-family: 'Courier New', monospace;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🦠 API de Reconhecimento de Plâncton</h1>
            
            <div class="status">
                <strong>Status:</strong> ✅ Servidor ativo e funcionando
            </div>
            
            <h2>Endpoints Disponíveis:</h2>
            
            <div class="endpoint">
                <h3><span class="method">GET</span> /</h3>
                <p>Página inicial com informações da API</p>
            </div>
            
            <div class="endpoint">
                <h3><span class="method">GET</span> /status</h3>
                <p>Verifica o status do servidor e do modelo de IA</p>
            </div>
            
            <div class="endpoint">
                <h3><span class="method">POST</span> /predict</h3>
                <p>Classifica uma imagem de plâncton</p>
                <p><strong>Parâmetros:</strong></p>
                <ul>
                    <li><code>file</code>: Arquivo de imagem (PNG, JPG, JPEG, GIF, BMP, TIFF)</li>
                </ul>
                <p><strong>Resposta:</strong> JSON com a classificação e confiança</p>
            </div>
            
            <div class="endpoint">
                <h3><span class="method">POST</span> /predict_base64</h3>
                <p>Classifica uma imagem de plâncton enviada em base64</p>
                <p><strong>Parâmetros JSON:</strong></p>
                <ul>
                    <li><code>image</code>: String base64 da imagem</li>
                </ul>
                <p><strong>Resposta:</strong> JSON com a classificação e confiança</p>
            </div>
            
            <div class="endpoint">
                <h3><span class="method">GET</span> /classes</h3>
                <p>Lista todas as classes de plâncton que o modelo pode identificar</p>
            </div>
            
            <h2>Classes de Plâncton Suportadas:</h2>
            <ul>
                <li>Copepod</li>
                <li>Diatom</li>
                <li>Dinoflagellate</li>
                <li>Radiolarian</li>
                <li>Foraminifera</li>
                <li>Cyanobacteria</li>
                <li>Other</li>
            </ul>
            
            <h2>Exemplo de Uso:</h2>
            <pre><code>curl -X POST -F "file=@imagem_plancton.jpg" http://localhost:5000/predict</code></pre>
        </div>
    </body>
    </html>
    """
    return render_template_string(html_template)

@app.route('/status', methods=['GET'])
def status():
    """Retorna o status do servidor e do modelo."""
    model_info = plankton_classifier.get_model_info()
    return jsonify({
        'status': 'online',
        'message': 'Servidor de reconhecimento de plâncton ativo',
        'model_info': model_info,
        'endpoints': [
            'GET /',
            'GET /status',
            'POST /predict',
            'POST /predict_base64',
            'GET /classes'
        ]
    })

@app.route('/classes', methods=['GET'])
def get_classes():
    """Retorna as classes de plâncton suportadas."""
    return jsonify({
        'classes': plankton_classifier.class_names,
        'num_classes': len(plankton_classifier.class_names)
    })

@app.route('/predict', methods=['POST'])
def predict_file():
    """Classifica uma imagem de plâncton enviada como arquivo."""
    try:
        # Verifica se foi enviado um arquivo
        if 'file' not in request.files:
            return jsonify({'error': 'Nenhum arquivo enviado'}), 400
        
        file = request.files['file']
        
        # Verifica se o arquivo tem nome
        if file.filename == '':
            return jsonify({'error': 'Nenhum arquivo selecionado'}), 400
        
        # Verifica se o arquivo é permitido
        if not allowed_file(file.filename):
            return jsonify({
                'error': 'Tipo de arquivo não permitido',
                'allowed_types': list(ALLOWED_EXTENSIONS)
            }), 400
        
        # Salva o arquivo temporariamente
        filename = secure_filename(file.filename)
        unique_filename = f"{uuid.uuid4()}_{filename}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        file.save(filepath)
        
        try:
            # Faz a predição
            result = plankton_classifier.predict(filepath)
            
            # Remove o arquivo temporário
            os.remove(filepath)
            
            if 'error' in result:
                return jsonify(result), 500
            
            return jsonify({
                'success': True,
                'filename': filename,
                'prediction': result
            })
            
        except Exception as e:
            # Remove o arquivo em caso de erro
            if os.path.exists(filepath):
                os.remove(filepath)
            raise e
            
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@app.route('/predict_base64', methods=['POST'])
def predict_base64():
    """Classifica uma imagem de plâncton enviada em base64."""
    try:
        data = request.get_json()
        
        if not data or 'image' not in data:
            return jsonify({'error': 'Dados JSON inválidos ou campo "image" ausente'}), 400
        
        # Decodifica a imagem base64
        try:
            image_data = base64.b64decode(data['image'])
        except Exception as e:
            return jsonify({'error': 'Dados base64 inválidos'}), 400
        
        # Salva a imagem temporariamente
        with tempfile.NamedTemporaryFile(delete=False, suffix='.jpg') as temp_file:
            temp_file.write(image_data)
            temp_filepath = temp_file.name
        
        try:
            # Faz a predição
            result = plankton_classifier.predict(temp_filepath)
            
            # Remove o arquivo temporário
            os.remove(temp_filepath)
            
            if 'error' in result:
                return jsonify(result), 500
            
            return jsonify({
                'success': True,
                'prediction': result
            })
            
        except Exception as e:
            # Remove o arquivo em caso de erro
            if os.path.exists(temp_filepath):
                os.remove(temp_filepath)
            raise e
            
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@app.errorhandler(413)
def too_large(e):
    """Handler para arquivos muito grandes."""
    return jsonify({'error': 'Arquivo muito grande. Tamanho máximo: 16MB'}), 413

@app.errorhandler(404)
def not_found(e):
    """Handler para rotas não encontradas."""
    return jsonify({'error': 'Endpoint não encontrado'}), 404

@app.errorhandler(500)
def internal_error(e):
    """Handler para erros internos."""
    return jsonify({'error': 'Erro interno do servidor'}), 500

if __name__ == '__main__':
    print("🦠 Iniciando servidor de reconhecimento de plâncton...")
    print("📡 Servidor rodando em: http://0.0.0.0:5000")
    print("📋 Acesse http://localhost:5000 para ver a documentação da API")
    
    # Verifica se o modelo está carregado
    model_info = plankton_classifier.get_model_info()
    if model_info.get('model_loaded'):
        print("✅ Modelo de IA carregado com sucesso!")
        print(f"🔬 Classes suportadas: {', '.join(model_info['classes'])}")
    else:
        print("❌ Erro ao carregar o modelo de IA!")
    
    app.run(host='0.0.0.0', port=5000, debug=True)


