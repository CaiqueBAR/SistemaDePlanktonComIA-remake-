import tkinter as tk
from tkinter import messagebox, filedialog, ttk
from tkinter import scrolledtext
import subprocess
import threading
import os
import sys
import requests
import json
import base64
from PIL import Image, ImageTk
import io

class PlanktonAIApp:
    def __init__(self, master):
        self.master = master
        master.title("Sistema de Reconhecimento de Plâncton com IA")
        master.geometry("900x700")
        master.configure(bg=\'#f0f0f0\')
        
        # Variáveis
        self.process = None
        self.server_url = "http://localhost:5000"
        self.current_image_path = None
        self.current_image = None
        
        # Configuração do estilo
        self.setup_styles()
        
        # Criação da interface
        self.create_widgets()
        
        # Verifica se o servidor já está rodando
        self.check_server_status()
    
    def setup_styles(self):
        """Configura os estilos da interface."""
        self.colors = {
            \'primary\': \'#2c3e50\',
            \'secondary\': \'#3498db\',
            \'success\': \'#27ae60\',
            \'danger\': \'#e74c3c\',
            \'warning\': \'#f39c12\',
            \'light\': \'#ecf0f1\',
            \'dark\': \'#34495e\'
        }
    
    def create_widgets(self):
        """Cria todos os widgets da interface."""
        # Frame principal
        main_frame = tk.Frame(self.master, bg=\'#f0f0f0\')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Título
        title_label = tk.Label(
            main_frame, 
            text="🦠 Sistema de Reconhecimento de Plâncton com IA",
            font=(\'Arial\', 16, \'bold\'),
            bg=\'#f0f0f0\',
            fg=self.colors[\'primary\']
        )
        title_label.pack(pady=(0, 20))
        
        # Frame do servidor
        self.create_server_frame(main_frame)
        
        # Frame da IA
        self.create_ai_frame(main_frame)
        
        # Frame de logs
        self.create_log_frame(main_frame)
    
    def create_server_frame(self, parent):
        """Cria o frame de controle do servidor."""
        server_frame = tk.LabelFrame(
            parent, 
            text="Controle do Servidor Flask",
            font=(\'Arial\', 12, \'bold\'),
            bg=\'#f0f0f0\',
            fg=self.colors[\'primary\'],
            padx=10,
            pady=10
        )
        server_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Status do servidor
        status_frame = tk.Frame(server_frame, bg=\'#f0f0f0\')
        status_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Label(
            status_frame, 
            text="Status:",
            font=(\'Arial\', 10, \'bold\'),
            bg=\'#f0f0f0\'
        ).pack(side=tk.LEFT)
        
        self.status_label = tk.Label(
            status_frame, 
            text="Servidor parado",
            fg=self.colors[\'danger\'],
            bg=\'#f0f0f0\',
            font=(\'Arial\', 10)
        )
        self.status_label.pack(side=tk.LEFT, padx=(5, 0))
        
        # Botões do servidor
        button_frame = tk.Frame(server_frame, bg=\'#f0f0f0\')
        button_frame.pack(fill=tk.X)
        
        self.start_button = tk.Button(
            button_frame,
            text="🚀 Iniciar Servidor",
            command=self.start_server,
            bg=self.colors[\'success\'],
            fg=\'white\',
            font=(\'Arial\', 10, \'bold\'),
            padx=20,
            pady=5
        )
        self.start_button.pack(side=tk.LEFT, padx=(0, 10))
        
        self.stop_button = tk.Button(
            button_frame,
            text="⏹️ Parar Servidor",
            command=self.stop_server,
            bg=self.colors[\'danger\'],
            fg=\'white\',
            font=(\'Arial\', 10, \'bold\'),
            padx=20,
            pady=5,
            state=tk.DISABLED
        )
        self.stop_button.pack(side=tk.LEFT, padx=(0, 10))
        
        self.check_button = tk.Button(
            button_frame,
            text="🔍 Verificar Status",
            command=self.check_server_status,
            bg=self.colors[\'secondary\'],
            fg=\'white\',
            font=(\'Arial\', 10, \'bold\'),
            padx=20,
            pady=5
        )
        self.check_button.pack(side=tk.LEFT)
    
    def create_ai_frame(self, parent):
        """Cria o frame de funcionalidades da IA."""
        ai_frame = tk.LabelFrame(
            parent, 
            text="Reconhecimento de Plâncton com IA",
            font=(\'Arial\', 12, \'bold\'),
            bg=\'#f0f0f0\',
            fg=self.colors[\'primary\'],
            padx=10,
            pady=10
        )
        ai_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Frame superior (imagem e controles)
        top_frame = tk.Frame(ai_frame, bg=\'#f0f0f0\')
        top_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Frame da imagem
        image_frame = tk.Frame(top_frame, bg=\'#f0f0f0\')
        image_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Canvas para exibir a imagem
        self.image_canvas = tk.Canvas(
            image_frame,
            width=300,
            height=300,
            bg=\'white\',
            relief=tk.SUNKEN,
            borderwidth=2
        )
        self.image_canvas.pack(pady=(0, 10))
        
        # Botão para selecionar imagem
        self.select_image_button = tk.Button(
            image_frame,
            text="📁 Selecionar Imagem",
            command=self.select_image,
            bg=self.colors[\'secondary\'],
            fg=\'white\',
            font=(\'Arial\', 10, \'bold\'),
            padx=20,
            pady=5
        )
        self.select_image_button.pack()
        
        # Frame dos resultados
        results_frame = tk.Frame(top_frame, bg=\'#f0f0f0\')
        results_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(20, 0))
        
        tk.Label(
            results_frame,
            text="Resultados da Classificação:",
            font=(\'Arial\', 11, \'bold\'),
            bg=\'#f0f0f0\',
            fg=self.colors[\'primary\']
        ).pack(anchor=tk.W)
        
        # Área de resultados
        self.results_text = scrolledtext.ScrolledText(
            results_frame,
            height=15,
            width=40,
            font=(\'Courier\', 9),
            bg=\'white\',
            relief=tk.SUNKEN,
            borderwidth=2
        )
        self.results_text.pack(fill=tk.BOTH, expand=True, pady=(5, 10))
        
        # Botão para classificar
        self.classify_button = tk.Button(
            results_frame,
            text="🔬 Classificar Plâncton",
            command=self.classify_image,
            bg=self.colors[\'warning\'],
            fg=\'white\',
            font=(\'Arial\', 10, \'bold\'),
            padx=20,
            pady=5,
            state=tk.DISABLED
        )
        self.classify_button.pack()
    
    def create_log_frame(self, parent):
        """Cria o frame de logs do servidor."""
        log_frame = tk.LabelFrame(
            parent, 
            text="Logs do Servidor",
            font=(\'Arial\', 12, \'bold\'),
            bg=\'#f0f0f0\',
            fg=self.colors[\'primary\'],
            padx=10,
            pady=10
        )
        log_frame.pack(fill=tk.X)
        
        self.log_text = scrolledtext.ScrolledText(
            log_frame,
            height=8,
            font=(\'Courier\', 8),
            bg=\'black\',
            fg=\'green\',
            relief=tk.SUNKEN,
            borderwidth=2
        )
        self.log_text.pack(fill=tk.X)
    
    def log_message(self, message, level="INFO"):
        """Adiciona uma mensagem ao log."""
        colors = {
            "INFO": "green",
            "ERROR": "red",
            "WARNING": "yellow",
            "SUCCESS": "cyan"
        }
        
        self.log_text.insert(tk.END, f"[{level}] {message}\\n")
        self.log_text.see(tk.END)
        self.log_text.update()
    
    def start_server(self):
        """Inicia o servidor Flask."""
        if self.process is None:
            flask_script_path = os.path.abspath("flask_server.py")
            
            if not os.path.exists(flask_script_path):
                messagebox.showerror("Erro", f"Arquivo {flask_script_path} não encontrado!")
                return
            
            try:
                self.process = subprocess.Popen(
                    [sys.executable, flask_script_path],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    universal_newlines=True,
                    bufsize=1
                )
                
                self.status_label.config(text="Servidor iniciando...", fg=self.colors[\'warning\'])
                self.start_button.config(state=tk.DISABLED)
                self.stop_button.config(state=tk.NORMAL)
                
                self.log_message("Iniciando servidor Flask...", "INFO")
                
                # Inicia thread para ler output
                threading.Thread(target=self.read_output, daemon=True).start()
                
                # Verifica se o servidor está rodando após alguns segundos
                self.master.after(3000, self.check_server_after_start)
                
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao iniciar servidor: {e}")
                self.log_message(f"Erro ao iniciar servidor: {e}", "ERROR")
    
    def stop_server(self):
        """Para o servidor Flask."""
        if self.process:
            self.process.terminate()
            self.process = None
            self.status_label.config(text="Servidor parado", fg=self.colors[\'danger\'])
            self.start_button.config(state=tk.NORMAL)
            self.stop_button.config(state=tk.DISABLED)
            self.classify_button.config(state=tk.DISABLED)
            self.log_message("Servidor parado", "INFO")
    
    def read_output(self):
        """Lê o output do processo Flask."""
        if not self.process:
            return
        
        try:
            for line in iter(self.process.stdout.readline, \'\'):
                if line:
                    self.log_message(line.strip(), "INFO")
                if self.process.poll() is not None:
                    break
        except Exception as e:
            self.log_message(f"Erro ao ler output: {e}", "ERROR")
    
    def check_server_after_start(self):
        """Verifica o status do servidor após inicialização."""
        self.check_server_status()
    
    def check_server_status(self):
        """Verifica se o servidor está rodando."""
        try:
            response = requests.get(f"{self.server_url}/status", timeout=5)
            if response.status_code == 200:
                data = response.json()
                self.status_label.config(
                    text=f"Servidor ativo - {data.get(\'message\', \'OK\')}", 
                    fg=self.colors[\'success\']
                )
                self.classify_button.config(state=tk.NORMAL if self.current_image_path else tk.DISABLED)
                self.log_message("Servidor está ativo e respondendo", "SUCCESS")
            else:
                self.status_label.config(text="Servidor com problemas", fg=self.colors[\'warning\'])
                self.classify_button.config(state=tk.DISABLED)
                
        except requests.exceptions.RequestException:
            self.status_label.config(text="Servidor não acessível", fg=self.colors[\'danger\'])
            self.classify_button.config(state=tk.DISABLED)
    
    def select_image(self):
        """Abre diálogo para selecionar uma imagem."""
        file_types = [
            ("Imagens", "*.png *.jpg *.jpeg *.gif *.bmp *.tiff"),
            ("PNG", "*.png"),
            ("JPEG", "*.jpg *.jpeg"),
            ("Todos os arquivos", "*.*")
        ]
        
        file_path = filedialog.askopenfilename(
            title="Selecionar imagem de plâncton",
            filetypes=file_types
        )
        
        if file_path:
            self.current_image_path = file_path
            self.display_image(file_path)
            self.log_message(f"Imagem selecionada: {os.path.basename(file_path)}", "INFO")
            
            # Habilita o botão de classificar se o servidor estiver ativo
            if "ativo" in self.status_label.cget("text"):
                self.classify_button.config(state=tk.NORMAL)
    
    def display_image(self, image_path):
        """Exibe a imagem selecionada no canvas."""
        try:
            # Abre e redimensiona a imagem
            image = Image.open(image_path)
            
            # Calcula o tamanho para manter a proporção
            canvas_width = 300
            canvas_height = 300
            
            img_width, img_height = image.size
            ratio = min(canvas_width/img_width, canvas_height/img_height)
            
            new_width = int(img_width * ratio)
            new_height = int(img_height * ratio)
            
            image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
            
            # Converte para PhotoImage
            self.current_image = ImageTk.PhotoImage(image)
            
            # Limpa o canvas e exibe a imagem
            self.image_canvas.delete("all")
            
            # Centraliza a imagem
            x = (canvas_width - new_width) // 2
            y = (canvas_height - new_height) // 2
            
            self.image_canvas.create_image(x, y, anchor=tk.NW, image=self.current_image)
            
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao carregar imagem: {e}")
            self.log_message(f"Erro ao carregar imagem: {e}", "ERROR")
    
    def classify_image(self):
        """Envia a imagem para classificação."""
        if not self.current_image_path:
            messagebox.showwarning("Aviso", "Selecione uma imagem primeiro!")
            return
        
        try:
            self.log_message("Enviando imagem para classificação...", "INFO")
            self.classify_button.config(state=tk.DISABLED, text="Classificando...")
            
            # Envia a imagem para o servidor
            with open(self.current_image_path, \'rb\') as f:
                files = {\'file\': f}
                response = requests.post(f"{self.server_url}/predict", files=files, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                self.display_results(result)
                self.log_message("Classificação concluída com sucesso", "SUCCESS")
            else:
                error_msg = f"Erro na classificação: {response.status_code}"
                messagebox.showerror("Erro", error_msg)
                self.log_message(error_msg, "ERROR")
                
        except requests.exceptions.RequestException as e:
            error_msg = f"Erro de conexão: {e}"
            messagebox.showerror("Erro", error_msg)
            self.log_message(error_msg, "ERROR")
            
        except Exception as e:
            error_msg = f"Erro inesperado: {e}"
            messagebox.showerror("Erro", error_msg)
            self.log_message(error_msg, "ERROR")
            
        finally:
            self.classify_button.config(state=tk.NORMAL, text="🔬 Classificar Plâncton")
    
    def display_results(self, result):
        """Exibe os resultados da classificação."""
        self.results_text.delete(1.0, tk.END)
        
        if result.get(\'success\'):
            prediction = result[\'prediction\']
            
            # Resultado principal
            self.results_text.insert(tk.END, "=== RESULTADO DA CLASSIFICAÇÃO ===\\n\\n")
            self.results_text.insert(tk.END, f"Classe Predita: {prediction[\'predicted_class\']}\\n")
            self.results_text.insert(tk.END, f"Confiança: {prediction[\'confidence\']:.2%}\\n\\n")
            
            # Todas as probabilidades
            self.results_text.insert(tk.END, "=== TODAS AS PROBABILIDADES ===\\n\\n")
            
            # Ordena por probabilidade
            all_preds = prediction[\'all_predictions\']
            sorted_preds = sorted(all_preds.items(), key=lambda x: x[1], reverse=True)
            
            for class_name, probability in sorted_preds:
                bar_length = int(probability * 20)  # Barra de 20 caracteres
                bar = "█" * bar_length + "░" * (20 - bar_length)
                self.results_text.insert(tk.END, f"{class_name:<15} {bar} {probability:.2%}\\n")
            
            # Informações adicionais
            self.results_text.insert(tk.END, f"\\n=== INFORMAÇÕES ===\\n\\n")
            self.results_text.insert(tk.END, f"Arquivo: {result.get(\'filename\', \'N/A\')}\\n")
            
            # Interpretação do resultado
            confidence = prediction[\'confidence\']
            if confidence > 0.8:
                interpretation = "Alta confiança - Resultado muito provável"
            elif confidence > 0.6:
                interpretation = "Confiança moderada - Resultado provável"
            elif confidence > 0.4:
                interpretation = "Baixa confiança - Resultado incerto"
            else:
                interpretation = "Confiança muito baixa - Resultado duvidoso"
            
            self.results_text.insert(tk.END, f"Interpretação: {interpretation}\\n")
            
        else:
            self.results_text.insert(tk.END, "ERRO NA CLASSIFICAÇÃO\\n\\n")
            self.results_text.insert(tk.END, f"Detalhes: {result}\\n")

def main():
    """Função principal."""
    root = tk.Tk()
    app = PlanktonAIApp(root)
    
    # Configura o fechamento da aplicação
    def on_closing():
        if app.process:
            app.stop_server()
        root.destroy()
    
    root.protocol("WM_DELETE_WINDOW", on_closing)
    root.mainloop()

if __name__ == "__main__":
    main()

