import subprocess
import sys
import os
import time

FLASK_SCRIPT_PATH = os.path.abspath("flask_server.py")

def start_flask_server():
    print("Iniciando o servidor Flask...")
    try:
        # Usar Popen para iniciar o servidor em um processo separado
        # e não bloquear o script atual.
        # Redirecionar stdout e stderr para arquivos de log para depuração.
        stdout_file = open("flask_server_stdout.log", "w")
        stderr_file = open("flask_server_stderr.log", "w")
        process = subprocess.Popen(
            [sys.executable, FLASK_SCRIPT_PATH],
            stdout=stdout_file,
            stderr=stderr_file,
            # Detach the process from the current console
            # This is OS-dependent
            # For Windows: creationflags=subprocess.DETACHED_PROCESS
            # For Unix/Linux: preexec_fn=os.setsid
            preexec_fn=os.setsid if sys.platform != "win32" else None
        )
        print(f"Servidor Flask iniciado com PID: {process.pid}")
        print("Verifique \'flask_server_stdout.log\' e \'flask_server_stderr.log\' para logs.")
        return process
    except Exception as e:
        print(f"Erro ao iniciar o servidor Flask: {e}")
        return None

if __name__ == "__main__":
    # Este script pode ser executado diretamente para iniciar o servidor.
    # Ele não vai esperar o servidor terminar.
    start_flask_server()
    print("Script de inicialização do servidor Flask finalizado. O servidor deve estar rodando em segundo plano.")
    # Pequena pausa para garantir que o processo filho tenha tempo de iniciar
    time.sleep(2)


